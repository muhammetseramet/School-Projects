package v2x.laboratory.denm;

import v2x.laboratory.denm.header.ItsPduHeader;
import v2x.laboratory.denm.messagebody.DecentralizedEnvironmentalNotificationMessage;

public class DENM {

    private ItsPduHeader itsPduHeader;

    private DecentralizedEnvironmentalNotificationMessage decentralizedEnvironmentalNotificationMessage;

    public DENM() {
    }

    public DENM(ItsPduHeader itsPduHeader, DecentralizedEnvironmentalNotificationMessage decentralizedEnvironmentalNotificationMessage) {
        this.itsPduHeader = itsPduHeader;
        this.decentralizedEnvironmentalNotificationMessage = decentralizedEnvironmentalNotificationMessage;
    }

    public ItsPduHeader getItsPduHeader() {
        return itsPduHeader;
    }

    public void setItsPduHeader(ItsPduHeader itsPduHeader) {
        this.itsPduHeader = itsPduHeader;
    }

    public DecentralizedEnvironmentalNotificationMessage getDecentralizedEnvironmentalNotificationMessage() {
        return decentralizedEnvironmentalNotificationMessage;
    }

    public void setDecentralizedEnvironmentalNotificationMessage(DecentralizedEnvironmentalNotificationMessage decentralizedEnvironmentalNotificationMessage) {
        this.decentralizedEnvironmentalNotificationMessage = decentralizedEnvironmentalNotificationMessage;
    }

    @Override
    public String toString() {
        return "DENM{" +
                "itsPduHeader=" + itsPduHeader +
                ", decentralizedEnvironmentalNotificationMessage=" + decentralizedEnvironmentalNotificationMessage +
                '}';
    }
}
