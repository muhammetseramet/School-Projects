package v2x.laboratory.denm.elements.actionid;

public class StationID {

    private int originatingStationID;

    public StationID() {
    }

    public StationID(int originatingStationID) {
        this.originatingStationID = originatingStationID;
    }

    public int getOriginatingStationID() {
        return originatingStationID;
    }

    public void setOriginatingStationID(int originatingStationID) {
        this.originatingStationID = originatingStationID;
    }

    @Override
    public String toString() {
        return "StationID{" +
                "originatingStationID=" + originatingStationID +
                '}';
    }
}
