package v2x.laboratory.sample;

import v2x.laboratory.denm.DENM;
import v2x.laboratory.denm.containers.ManagementContainer;
import v2x.laboratory.denm.elements.actionid.ActionID;
import v2x.laboratory.denm.elements.actionid.SequenceNumber;
import v2x.laboratory.denm.elements.actionid.StationID;
import v2x.laboratory.denm.header.ItsPduHeader;
import v2x.laboratory.denm.messagebody.DecentralizedEnvironmentalNotificationMessage;

public class Main {

    //TODO replace this value with your neptun code
    private static String neptunCode = "ABCD123";

    //TODO replace this value with your taskID (the id of your homework in the moodle, start with "DENM - B.[XX]")
    private static String taskID = "DENM - B.7";

    public static void main(String[] args) {
        DENM denmMessage = new DENM();

        //TODO initialize your DENM message

        ItsPduHeader itsPduHeader = new ItsPduHeader();
        DecentralizedEnvironmentalNotificationMessage decentralizedEnvironmentalNotificationMessage
                = new DecentralizedEnvironmentalNotificationMessage();

        ManagementContainer managementContainer = new ManagementContainer();
        ActionID actionID = new ActionID();
        SequenceNumber sequenceNumber = new SequenceNumber(1312);
        StationID stationID = new StationID(1);

        actionID.setSequenceNumber(sequenceNumber);
        actionID.setStationID(stationID);

        managementContainer.setActionID(actionID);
        decentralizedEnvironmentalNotificationMessage.setManagementContainer(managementContainer);

        denmMessage.setDecentralizedEnvironmentalNotificationMessage(decentralizedEnvironmentalNotificationMessage);

        System.out.println("Neptun code: " + neptunCode);
        System.out.println("TaskID: " + taskID);
        System.out.println("DENM message structure: ");

        //TODO print your DENM structure
        System.out.println(denmMessage.toString());
    }
}
