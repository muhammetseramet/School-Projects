package v2x.laboratory.denm.containers;

import v2x.laboratory.denm.elements.actionid.ActionID;

public class ManagementContainer {

    private ActionID actionID;

    public ManagementContainer() {
    }

    public ActionID getActionID() {
        return actionID;
    }

    public void setActionID(ActionID actionID) {
        this.actionID = actionID;
    }

    @Override
    public String toString() {
        return "ManagementContainer{" + "\n" +
                "\tactionID=" + actionID +
                '}';
    }
}
