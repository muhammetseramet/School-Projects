package v2x.laboratory.denm.messagebody;


import v2x.laboratory.denm.containers.AlacarteContainer;
import v2x.laboratory.denm.containers.LocationContainer;
import v2x.laboratory.denm.containers.ManagementContainer;
import v2x.laboratory.denm.containers.SituationContainer;

public class DecentralizedEnvironmentalNotificationMessage {

    private ManagementContainer managementContainer;

    private SituationContainer situationContainer;

    private LocationContainer locationContainer;

    private AlacarteContainer alacarteContainer;

    public DecentralizedEnvironmentalNotificationMessage() {
    }

    public DecentralizedEnvironmentalNotificationMessage(ManagementContainer managementContainer, SituationContainer situationContainer, LocationContainer locationContainer, AlacarteContainer alacarteContainer) {
        this.managementContainer = managementContainer;
        this.situationContainer = situationContainer;
        this.locationContainer = locationContainer;
        this.alacarteContainer = alacarteContainer;
    }

    public ManagementContainer getManagementContainer() {
        return managementContainer;
    }

    public void setManagementContainer(ManagementContainer managementContainer) {
        this.managementContainer = managementContainer;
    }

    public SituationContainer getSituationContainer() {
        return situationContainer;
    }

    public void setSituationContainer(SituationContainer situationContainer) {
        this.situationContainer = situationContainer;
    }

    public LocationContainer getLocationContainer() {
        return locationContainer;
    }

    public void setLocationContainer(LocationContainer locationContainer) {
        this.locationContainer = locationContainer;
    }

    public AlacarteContainer getAlacarteContainer() {
        return alacarteContainer;
    }

    public void setAlacarteContainer(AlacarteContainer alacarteContainer) {
        this.alacarteContainer = alacarteContainer;
    }

    @Override
    public String toString() {
        return "DecentralizedEnvironmentalNotificationMessage{" + "\n" +
                "managementContainer=" + managementContainer + "\n" +
                ", situationContainer=" + situationContainer + "\n" +
                ", locationContainer=" + locationContainer + "\n" +
                ", alacarteContainer=" + alacarteContainer + "\n" +
                '}';
    }
}


