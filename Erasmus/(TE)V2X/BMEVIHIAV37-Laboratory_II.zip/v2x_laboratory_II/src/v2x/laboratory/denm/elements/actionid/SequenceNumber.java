package v2x.laboratory.denm.elements.actionid;

public class SequenceNumber {

    private int sequenceNumber;

    public SequenceNumber() {
    }

    public SequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @Override
    public String toString() {
        return "SequenceNumber{" +
                "sequenceNumber=" + sequenceNumber +
                '}';
    }
}
