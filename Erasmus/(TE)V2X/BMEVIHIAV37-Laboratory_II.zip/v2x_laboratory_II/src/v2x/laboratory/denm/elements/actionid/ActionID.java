package v2x.laboratory.denm.elements.actionid;

public class ActionID {

    private StationID stationID;

    private SequenceNumber sequenceNumber;

    public ActionID() {
    }

    public ActionID(StationID stationID, SequenceNumber sequenceNumber) {
        this.stationID = stationID;
        this.sequenceNumber = sequenceNumber;
    }

    public StationID getStationID() {
        return stationID;
    }

    public void setStationID(StationID stationID) {
        this.stationID = stationID;
    }

    public SequenceNumber getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(SequenceNumber sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    @Override
    public String toString() {
        return "ActionID{" + "\n" +
                "\t\tstationID=" + stationID + "\n" +
                "\t\tsequenceNumber=" + sequenceNumber + "\n" +
                '}';
    }
}
