package v2x.laboratory.denm.header;

public class ItsPduHeader {
}
