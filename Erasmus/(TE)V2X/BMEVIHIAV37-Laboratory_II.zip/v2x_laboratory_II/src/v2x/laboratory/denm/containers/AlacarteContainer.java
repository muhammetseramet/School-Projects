package v2x.laboratory.denm.containers;

public class AlacarteContainer {
}
